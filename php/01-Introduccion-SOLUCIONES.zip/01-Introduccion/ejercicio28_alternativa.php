<?php

$nombre_usuario = "jvadillo";
$marcas = ["Audi", "Seat", "Mercedes", "Volskwagen", "BMW", "Fiat"];

require "ejercicio28_alternativa.view.php";