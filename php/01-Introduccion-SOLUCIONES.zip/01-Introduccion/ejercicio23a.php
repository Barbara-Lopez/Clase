<?php

$estudiantes = ["Mikel", "Ane", "Markel", "Nora", "Danel", "Amaia", "Izaro"];

function generarElemento($elemento) {
    return "<li>$elemento</li>";
}

function generarListado($elementos) {
    $lista = "<ul>";
    for($i=0; $i<count($elementos); $i++) {
        $lista .= generarElemento($elementos[$i]); //<li>Mikel</li>
    }
    return $lista."</ul>";
}

require "ejercicio23.view.php";