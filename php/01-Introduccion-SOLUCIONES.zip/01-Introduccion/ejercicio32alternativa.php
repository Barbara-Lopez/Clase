<?php

$estudiantes = array(
    "Luis Scola" => [9, 8],
    "Pablo Prigioni" => [8, 4],
    "Sergi Vidal" => [7, 6],
    "Ramón Rivas" => [3.5, 6]
);

// Calcula la nota media de dos números
function calcularNotaMedia($nota1, $nota2) {
    return round(($nota1+$nota2)/2,2);
}

// Utilizando esta función nos ahorramos todos los IF de la función anterior.
function calcularEstilo($nota) {
    if ($nota < 5) {
        return "color: red";
    }
    return "color:black";
}


require "ejercicio32alternativa.view.php";