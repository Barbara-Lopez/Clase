<html>
<head>
    <title>Hola Mundo</title>
</head>
<body>

<?php
$texto = "Adios Mundo!!";
echo "<p>Hola mundo!<p>";
echo $texto;
?>



</body>
</html>
