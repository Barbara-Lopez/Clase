<?php

$estudiantes = ["Mikel", "Ane", "Markel", "Nora", "Danel", "Amaia", "Izaro"];

function generarElemento($elemento, $id) {
    return "<li id='$id'>$elemento</li>";
}

function generarListado($elementos) {
    $lista = "<ul>";
    for($i=0; $i<count($elementos); $i++) {
        $lista .= generarElemento($elementos[$i], $i); //<li>Mikel</li>
    }
    return $lista."</ul>";
}

require "ejercicio23.view.php";